import pygame
pygame.init()
#Variables 
X = 400
Y = 400
RED = (163, 0, 0)
BRED = (219, 0, 0)
BBRED = (240,0,0)
ORANGE = (255, 149, 0)
DIRT = (181, 101, 30)
YELLOW = (255, 234, 5)
GREEN = (30, 255, 0)
BLUE = (0, 63, 163)
LBLUE = (93, 149, 238)
PURPLE = (166, 0, 255)
BLACK = (0, 0, 0)
DGREY = (102, 102, 102)
GREY = (199,199,199)
LGREY = (150, 150, 150)
LLGREY = (209,209,209)
WHITE = (255, 255, 255)
CRATECOLOR = (87,104,133)
FACTORYBACKGROUND = (224,224,224)
TAmmoC = WHITE
GUNE = False
Dead = False
Scene2 = False
Scene3 = False
CrateBreakable = False
Crate3Broken = False
B = False
BreakableCrateX = 165
BreakableCrateY = 280
FACTORYGROUND = (211,197,197)
FACTORYGROUND2 = (130,125,125)
SKY = (135, 206, 235)
GUN = (SKY)
LDGREY = (120, 120, 120)
CRATEC = (214,146,0)
CRATEC2 = (173,118,0)
CRATE2 = (SKY)
CRATE = (SKY)
CRATE3UNBROKEN = (CRATE)
CRATE3UNBROKEN2 = (CRATE2)
CRATE3BROKENS2 = (SKY)
CRATE3BROKEN2S2 = (SKY)
CRATE3BROKEN = SKY
CRATE3BROKEN2 = SKY
BrokenCrate3X1 = 165
BrokenCrate3Y1 = 295
BrokenCrate3X2 = 200
BrokenCrate3Y2 = 275
BrokenCrate3X3 = 165
BrokenCrate3Y3 = 270
BrokenCrate3X4 = 185
BrokenCrate3Y4 = 275
BrokenCrate3X5 = 165
BrokenCrate3Y5 = 280
BrokenCrate3HidX = 1000
BrokenCrate3HidY = 1000
BCX1 = BrokenCrate3HidX
BCY1 = BrokenCrate3HidY
BCX2 = BrokenCrate3HidX
BCY2 = BrokenCrate3HidY
BCX3 = BrokenCrate3HidX
BCY3 = BrokenCrate3HidY
BCX4 = BrokenCrate3HidX
BCY4 = BrokenCrate3HidY
BCX5 = BrokenCrate3HidX
BCY5 = BrokenCrate3HidY

Bulletx = 1000
Enemy1 = ("Enemy")
Enemy2 = ("Enemy")
Enemy3 = ("Enemy")
Scenex2 = (300)
Sceney2 = (320)
Enemy1x = 300
Enemy1y = 380
Enemy2x = 380
Enemy2y = 380
Enemy3x = 380
Enemy3y = 380
EnemyC3 = (RED)
EnemyC2 = (RED)
EnemyC1 = (RED)
PlayerC = (BLACK)
Enemy2yDead = 380
VTIME = ("Time:")
Time = (VTIME)
TimeTx = 135
TimeTy = 10
PAmmoRefill = 8
PistolAmmo = 8
TAmmoT = ("Ammo:")
SCENE2SWAP = (GREEN)
SCENE2SWAP2 = (DIRT)
SCENE2SWAP3 = (SKY)
DeathScreenBG = (RED)
DeathScreenF1 = (RED)
DeathScreenF1 = (RED)
BACKGROUND = (163, 0, 0)

Default1 = ("Alejandro")
Default2 = ("Philip")
Default3 = ("Peterson")
Default4 = ("Megatron")
Name_Test = ("Name Test")
Player = ("You")
Generic_Name_1 = ("Bob")
Generic_Name_2 = ("Jonathan")
Generic_Name_3 = ("James")
Version = ("GreeInc InDev 1.7")
fontq = pygame.font.Font(None, 20)
fonta = pygame.font.Font(None, 20)
FontZ = 25
font0 = pygame.font.Font(None, 15)
font = pygame.font.Font(None, 25)
TimeZ = pygame.font.Font(None, FontZ)
font2 = pygame.font.Font(None, 15)
font3 = pygame.font.Font(None, 15)
font4 = pygame.font.Font(None, 15)
fonte = pygame.font.Font(None, 12)
GameOver = pygame.font.Font(None, 50)

pi = 3.14
rect_x = 0
rect_y = 320





movement_x = 1.2
movement_y = 1.0
#Dislay stuff \/
DISPLAY = pygame.display.set_mode([X, Y])
pygame.display.set_caption('GreenInc InDev')
#===============================#
running = True
total_seconds = 0
frame_count = 0
clock = pygame.time.Clock()
# Game code\/
#Movement/KEYS code moved

while running:
	DISPLAY.fill(SCENE2SWAP3)


	
	if Scene2 == True:
		pygame.draw.rect(DISPLAY, GREY, [250, 40, 200, 300])
		pygame.draw.rect(DISPLAY, DGREY, [250, 320, 150, 20])
		pygame.draw.rect(DISPLAY, DGREY, [250, 40, 20, 280])
		pygame.draw.rect(DISPLAY, LBLUE, [320, 300, 40, 40])
		pygame.draw.rect(DISPLAY, DGREY, [315, 300, 5, 20])
		pygame.draw.rect(DISPLAY, DGREY, [360, 300, 5, 20])
		pygame.draw.rect(DISPLAY, DGREY, [315, 295, 50, 5])
		pygame.draw.rect(DISPLAY, DGREY, [337.5, 300, 5, 40])
		Enemy1x = Enemy1x - 0.5
		Enemy1y = 320
		CRATE3UNBROKEN = CRATE3BROKENS2
		CRATE3UNBROKEN2 = CRATE3BROKEN2S2
		CRATE3BROKEN = SKY
		CRATE3BROKEN2 = SKY
	if Scene2 == False:
		Enemy1y = 380

	if Scene3 == True:
		SCENE2SWAP = FACTORYGROUND2
		SCENE2SWAP2 = FACTORYGROUND2
		SCENE2SWAP3 = FACTORYBACKGROUND
		CRATE = CRATEC
		CRATE2 = CRATEC2
		CRATE3UNBROKEN = CRATE
		CRATE3UNBROKEN2 = CRATE2
		CRATE3BROKEN = FACTORYBACKGROUND
		CRATE3BROKEN2 = FACTORYBACKGROUND
		if Enemy3 == ("Enemy"):
			Enemy2y = 320
		if Enemy2 == ("Enemy"):
			Enemy2y = 320
			Enemy2x = Enemy2x - 0.5
	if Scene3 == False:
		CRATE3UNBROKEN = CRATE3BROKENS2
		CRATE3UNBROKEN2 = CRATE3BROKEN2S2
		Enemy2y = (Enemy2yDead)
		Enemy3y = 380

	if Enemy2 == ("Enemy"):
		Enemy3y = 380
	elif Enemy2 == ("Dead"):
		if Enemy3 == ("Enemy"):
			Enemy3y = 320
	
	if Enemy3 == ("Dead"):
		CrateBreakable = True
	#if CrateBreakable == True:
		#if Bulletx == BreakableCrateX + 5 and rect_y == BreakableCrateY:
			#Crate3Broken = True
	#if Scene3 == True:
		if Crate3Broken == True:
			CRATE3UNBROKEN = FACTORYBACKGROUND
			CRATE3UNBROKEN2 = FACTORYBACKGROUND 
			CRATE3BROKEN = CRATE
			CRATE3BROKEN2 = CRATE2
	

	
	
	
	
	
	

	if rect_x == 320 and rect_y == 320:
		if Scene2 == True:
			if Dead == False:
				if Enemy1 == ("Dead"):
					Scene2 = False
					Enemy1y = 400
					Scene3 = True
					rect_x = -10

	Bulletx = Bulletx + 4.5
	
	
	if Bulletx == Enemy1x and rect_y == Enemy1y:
		EnemyC1 = DGREY
		Enemy1 = ("Dead")
	if Enemy1 == ("Dead"):
		Enemy1x = Enemy1x + 0.5
		Enemy1y = Enemy1y + 10
	if Enemy1x == rect_x and Enemy1y == rect_y:
		Player = ("dead")
		Dead = True
		print("\033[0;32;47mPress Run to restart game.\n")


	
	
	if Scene2 == True:
		if GUNE == False:
			if Enemy1 == ("Enemy"):
				if rect_x == 220:
					GUN = (DGREY)
	if Scene2 == True:
		if GUNE == False:
			if Enemy1 == ("Enemy"):
				if Dead == False:
					if rect_x <= 219:
						GUN = (SKY)
	

	if total_seconds == 300:
		pygame.display.set_caption('Reloading...')
	if total_seconds == 305:
		pygame.display.set_caption('Reloaded!')
	if total_seconds == 306:
		pygame.display.set_caption("GreenInc InDev")
		print("Reloaded Title")
	
	
	
	
	
	pygame.draw.rect(DISPLAY, CRATE, [190, 300, 40, 40])
	pygame.draw.rect(DISPLAY, CRATE2, [190, 300, 40, 5]) 
	pygame.draw.rect(DISPLAY, CRATE2, [190, 305, 5, 35])
	pygame.draw.rect(DISPLAY, CRATE2, [225, 305, 5, 35])
	pygame.draw.rect(DISPLAY, CRATE2, [195, 335, 30, 5]) 
	pygame.draw.line(DISPLAY, CRATE2, [190, 300], [230, 340], 5)
	pygame.draw.line(DISPLAY, CRATE2, [230, 300], [190, 340], 5)
	pygame.draw.rect(DISPLAY,CRATE,[145, 300, 40, 40])
	pygame.draw.rect(DISPLAY, CRATE2, [145, 300, 40, 5])
	pygame.draw.rect(DISPLAY, CRATE2, [145, 305, 5, 40])
	pygame.draw.rect(DISPLAY, CRATE2, [180, 305, 5, 40])
	pygame.draw.rect(DISPLAY, CRATE2, [150, 335, 30, 5])
	pygame.draw.line(DISPLAY, CRATE2, [145, 300], [185, 340], 5)
	pygame.draw.line(DISPLAY, CRATE2, [185, 300], [145, 340], 5)
	pygame.draw.rect(DISPLAY, CRATE3UNBROKEN,[165, 260, 40,40])
	pygame.draw.rect(DISPLAY, CRATE3UNBROKEN2, [165, 260, 40, 5])
	pygame.draw.rect(DISPLAY, CRATE3UNBROKEN2, [165, 265, 5, 35])
	pygame.draw.rect(DISPLAY, CRATE3UNBROKEN2, [200,265, 5, 35])
	pygame.draw.rect(DISPLAY, CRATE3UNBROKEN2, [170, 295, 30, 5])
	pygame.draw.line(DISPLAY, CRATE3UNBROKEN2, [165, 260], [205, 300], 5)
	pygame.draw.line(DISPLAY, CRATE3UNBROKEN2, [205, 260], [165, 300],5)
	
	pygame.draw.rect(DISPLAY, CRATE3BROKEN, [BCX5, BCY5, 20, 15])
	pygame.draw.rect(DISPLAY, CRATE3BROKEN, [BCX4, BCY4, 15, 20])
	pygame.draw.rect(DISPLAY, CRATE3BROKEN2, [BCX3, BCY3, 5, 30])
	pygame.draw.rect(DISPLAY, CRATE3BROKEN2, [BCX2, BCY2, 5, 20])
	pygame.draw.rect(DISPLAY, CRATE3BROKEN2, [BCX1, BCY1, 40, 5])
	
	
	pygame.draw.rect(DISPLAY, LGREY, [0, 0, 600, 40])
	pygame.draw.rect(DISPLAY, PlayerC, [rect_x, rect_y, 20, 20])
	pygame.draw.rect(DISPLAY, GUN, [rect_x + 24, rect_y + 4, 6, 12])
	pygame.draw.rect(DISPLAY, GUN, [rect_x + 30, rect_y + 4, 12, 6])
	pygame.draw.rect(DISPLAY, YELLOW, [Bulletx + 35, rect_y + 5, 5, 5])
	pygame.draw.rect(DISPLAY, EnemyC1, [Enemy1x, Enemy1y, 20, 20])
	pygame.draw.rect(DISPLAY, EnemyC2, [Enemy2x, Enemy2y, 20, 20])
	pygame.draw.rect(DISPLAY, EnemyC3, [Enemy3x, Enemy3y, 20, 20])
	
	pygame.draw.rect(DISPLAY, DGREY, [320, 42.5, 76, 30])
	
	pygame.draw.rect(DISPLAY,SCENE2SWAP, [0, 340, 600,20])
	pygame.draw.rect(DISPLAY,SCENE2SWAP2, [0, 360, 600,600])
	pygame.draw.rect(DISPLAY, DGREY, [5, 5, 95, 25])
	pygame.draw.rect(DISPLAY, DGREY, [250, 5, 145, 25])
	pygame.draw.rect(DISPLAY, DGREY, [125, 5, 100, 25])
#This has been optimized for 400x400 screens change back for 600x600
	#print("\033[0;30;47m Woosh! \n")


	if rect_x >= 400:
		if Scene2 == False:
			if Scene3 == False:
				rect_x = -10
				print("\033[0;30;47m Woosh! \n")
				Scene2 = True

	if rect_x <= -20:
		if Scene2 == False:
			if Scene3 == False:
				rect_x = 390
				print("\033[0;30;47m Woosh! \n")
	if rect_x >= 400:
		if Scene2 == True:
			if Scene3 == False:
				rect_x = 380
				print("\033[0;37;41m There Seems to be a barrier.\n")

	if rect_x <= -20:
		if Scene2 == True:
			if Scene3 == False:
				rect_x = 390
				print("\033[0;30;47m Woosh! \n")
				Scene2 = False
	
	if rect_x <= -20:
		if Scene2 == False:
			if Scene3 == True:
				rect_x = 310
				print("\033[0;30;47m Woosh!\n")
				Scene3 = False
				Scene2 = True
				SCENE2SWAP = GREEN
				SCENE2SWAP2 = DIRT
				SCENE2SWAP3 = SKY
				CRATE = SKY
				CRATE2 = SKY
	
	if rect_x >= 400:
		if Scene2 == False:
			if Scene3 == True:
				rect_x = -10

	if Enemy2x == -10:
		if Scene2 == False:
			if Scene3 == True:
				Enemy2x = 390

	if Bulletx == Enemy2x and rect_y == Enemy2y:
		EnemyC2 = DGREY
		Enemy2 = ("Dead")
	if Enemy2 == ("Dead"):
		Enemy2x = Enemy2x + 0.5
		Enemy2y = 330


	
	if rect_y  == 340:
		rect_y = 320
		print("\033[0;37;41m You Can Not Go Into The Ground! \n")
	if rect_y <= 35:
		rect_y = 320
		print("\033[0;37;41m You Reached Max Height! \n")
	elif Enemy1x <= -20:
		Enemy1x = 390
	if Enemy3x == -10:
		Enemy3x = 390

	if Enemy2 == ("Dead"):
		if Scene2 == False:
			if Scene3 == True:
				Enemy3y = 320
				Enemy3x = Enemy3x - 0.5
				Enemy2x = Enemy2x - 0.5

	if Bulletx == Enemy3x and rect_y == Enemy3y:
		if Scene2 == False:
			if Scene3 == True:
				Enemy3 = ("Dead")
				EnemyC3 = DGREY

	if Enemy3x == rect_x and Enemy3y == rect_y:
		Dead = True

	if Enemy3 == ("Dead"):
		Enemy3y = 330
		Enemy3x = Enemy3x + 0.5








	#anl = font2.render(str(Bulletx), True, WHITE)
	#DISPLAY.blit(anl, [40, 60])
	#anl2 = font2.render(str(Enemy1x), True, WHITE)
	#DISPLAY.blit(anl2, [40, 80])
	anl3 = font2.render(str(rect_x), True, WHITE)
	DISPLAY.blit(anl3, [40, 90])
	anl4 = font2.render(str(rect_y), True, WHITE)
	DISPLAY.blit(anl4, [40, 100])
	
	
	
	text2 = font2.render(Player, True, WHITE)
	DISPLAY.blit(text2, [rect_x, rect_y,])
	texte = fonte.render(Enemy1, True, WHITE)
	DISPLAY.blit(texte, [Enemy1x - 3, Enemy1y,])
	e2 = fonte.render(Enemy2, True, WHITE)
	DISPLAY.blit(e2, [Enemy2x - 3, Enemy2y,])
	enemyy3 = fonte.render(Enemy3, True, WHITE)
	DISPLAY.blit(enemyy3, [Enemy3x - 3, Enemy3y,])
	
	text3 = font3.render("Press h for movement guide", True, WHITE)
	DISPLAY.blit(text3, [253, 12,])
	text0 = font4.render(Version, True, WHITE)
	DISPLAY.blit(text0, [5, 45,])
	text5 = font4.render(Version, True, WHITE)
	DISPLAY.blit(text5, [5, 365,])
	text = font.render(Name_Test, True, WHITE)
	DISPLAY.blit(text, [10, 10])
	Game_Over = GameOver.render("Game Over", True, BRED)
	if Dead == True:
		pygame.draw.rect(DISPLAY, DGREY, [ 100, 185, 205, 40])
		DISPLAY.blit(Game_Over, [110,190]) 
		SCENE2SWAP3 = (RED)
		SCENE2SWAP = (RED)
		SCENE2SWAP2 = (RED)
		CRATE = (RED)
		CRATE2 = (RED)
		EnemyC1 = (BLACK)
		GUN = (RED)
		frame_count -= 1
		PlayerC = (DGREY)
		rect_y = 330
		Time = ("Lived For:")
		TimeTx = 125




#=============================#
	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_a:
				if Dead == False:
					rect_x = rect_x - 10
			elif event.key == pygame.K_d:
				if Dead == False:
					rect_x = rect_x + 10
			elif event.key == pygame.K_w:
				if Dead == False:
					rect_y = rect_y - 10
					print("\033[0;30;47m Boing! \n")
			elif event.key == pygame.K_s:
				if Dead == False:
					rect_y = rect_y + 10
			elif event.key == pygame.K_q:
				if Dead == False:
					rect_y = 320
					print("*Thud*")
			elif event.key == pygame.K_x:
				if Dead == False:
					rect_x = rect_x + 20
			elif event.key == pygame.K_z:
				if Dead == False:
					rect_x = rect_x - 20
			elif event.key == pygame.K_e:
				if Dead == False:
					rect_y = rect_y - 20
					print("\033[0;30;47m *Super Jump* \n")
			elif event.key == pygame.K_h:
				print("""\033[0;30;47mBug Report
Multiple Bugs fixed.
--------------------
Ver Proto 6.2 bug fixed when player is over enemy and player dies.
===============
Ver Proto 6.61:
Fixed bug for when player is able to shoot when gun is not equiped.
===============
Ver Proto 6.62:
Fixed bug when gun is equiped and player shoots enemy, Enemy now dies. (May take 3 shots or more)
==============
Ver Proto 7.31:
Fixed Enemy2 bug.
==============
Ver Proto 7.41:
Enemy2 appearing glitch fixed.
==============
Ver Proto 7.4 - 7.5:
Enemy2 & 3 Gltiched fixied.
==============
InDev 1.5:
Fixed Crate Breaking Bug.
==============
InDev 1.7
Fixed Crate Overlapping Crate Bug.
-------
Updates
-------
Update Proto 6.5:
If Player dies then Player cannot move.
==================
Update Proto 6.51:
When Player dies Game Over screen shows.
Removed N and M as functioning Keys.
Player can no longer swap Scenes.
==================
Update Proto 6.52:
Added Kill Button
=================
Update Proto 6.6:
Added New Scene. (Factory)
Enemy moved to Scene2.
==================
Update Proto 6.61:
Player must toggle gun to shoot.
==================
Update Proto 6.7:
Added Reload machanic.
==================
Update Proto 6.71:
Added color to reload mechanic if ran out of ammo.
==================
Update Proto 6.72:
Improved internal mechanic for switching zones.
Added a "Barrier"
=================
Update Proto 6.73:
Player can now reload weapon if weaponn has less then 8 Ammo.
Added mechanic to put gun away.
=================
Update Proto 7:
Added interior of factory.
Factory Refurbished.
=================
Update Proto 7.1:
Swapped movement keys from Arrow keys to WASD.
=================
Update Proto 7.12:
Updated Movement Guide.
=================
Update Proto 7.2:
Added Crates in factory.
=================
Update Proto 7.21:
Added Enemy2 Prototype.
=================
Update Proto 7.3:
Enemy2 fully coded in.
=================
Update Proto 7.31:
Fixed Enemy2
=================
Update Proto 7.4 - 7.5:
Added Enemy3
=================
Update Proto 7.5:
Added a mechanic to brake a crate in factory.
(Mechanic Not Ready.)
=================
Update InDev 1.0:
Game is now InDev.
=================
Update InDev 1.5:
Crate breaking mechanic implemented.
(To Break Crate Shoot Crate *May Take More than three shots like the enemys*)
=================
Update InDev 1.6:
Changed Mechanic to break crate to pressing B key when behind crate.
=================
Update InDev 1.7:
Fixed Bug.
-------------

MovementGuide
WASD Keys for movement. Z&X for Running. Q for teleporting to ground when in air. E for Super Jump. G/T to equip/unequip weapon. F to shoot weapon. R to Reload weapon C,V 
\n""")
			#elif event.key == pygame.K_m:
				#if Dead == False:
					#SCENE2SWAP = (FACTORYGROUND2)
					#SCENE2SWAP2 = (FACTORYGROUND2)
					#rect_x = 0
					#rect_y = 320
					#print("Scene Swapped")
					#GUN = (FACTORYBACKGROUND)
					#SCENE2SWAP3 = (FACTORYBACKGROUND)
					#CRATE = (CRATECOLOR)
			#elif event.key == pygame.K_n:
				#if Dead == False:
					#SCENE2SWAP = (GREEN)
					#SCENE2SWAP2 = (DIRT)
					#SCENE2SWAP3 = (SKY)
					#rect_x = 0
					#rect_y = 320
					#print("Scene Swapped Back")
					#GUN = (SKY)
					#CRATE = (SKY)
			elif event.key == pygame.K_c:
				if Dead == False:
					rect_x = rect_x - 30
			elif event.key == pygame.K_v:
				if Dead == False:
					rect_x = rect_x + 30
			elif event.key == pygame.K_g:
				if Dead == False:
					GUNE = True
					GUN = (LGREY)
			elif event.key == pygame.K_t:
				if Dead == False:
					GUNE = False
					GUN = (SKY)
			elif event.key == pygame.K_f:
				if PistolAmmo == 0:
					print("\033[0;31;47mReload!\n")
				if PistolAmmo >= 1:
					if Dead == False:
						if GUNE == True:
							PistolAmmo = PistolAmmo - 1
							Bulletx = rect_x
			elif event.key == pygame.K_k:
				if Dead == False:
					Dead = True
					Player = ("Dead")
					print("\033[0;32;47mPress Run to restart game.\n")
			elif event.key == pygame.K_r:
				if PistolAmmo <= 7:
					if Dead == False:
						if GUNE == True:
								PistolAmmo = 8
								print("\033[0;32;47mReloaded Weapon!\n")
			elif event.key == pygame.K_b:
				if Enemy3 == ("Dead"):
					if CrateBreakable == True:
						if rect_y == BreakableCrateY and rect_x == BreakableCrateX - 15:
							Crate3Broken = True
							BCX1 = BrokenCrate3X1
							BCY1 = BrokenCrate3Y1
							BCX2 = BrokenCrate3X2
							BCY2 = BrokenCrate3Y2
							BCX3 = BrokenCrate3X3
							BCY3 = BrokenCrate3Y3
							BCX4 = BrokenCrate3X4
							BCY4 = BrokenCrate3Y4
							BCX5 = BrokenCrate3X5
							BCY5 = BrokenCrate3Y5
							if Crate3Broken == True:
								print("Crack!")


#movement=controls===/\=======#
	PAmmo = fonta.render(str(PistolAmmo), True, TAmmoC)
	DISPLAY.blit(PAmmo, [380, 50])
	TAmmo = fontq.render(TAmmoT, True, TAmmoC)
	DISPLAY.blit(TAmmo, [ 330, 50])
	if PistolAmmo == 0:
		TAmmoC = (BBRED)
	elif PistolAmmo >= 7:
		TAmmoC = (WHITE)
#Clock Works \/
	total_seconds = frame_count // 60 
	minutes = total_seconds // 60
	seconds = total_seconds - (minutes * 60)
	
	output_string = Time + str(minutes) + ":" + str(seconds)

	text4 = TimeZ.render(output_string, True, WHITE)
	DISPLAY.blit(text4, [TimeTx, TimeTy])
	frame_count += 1
#=============================#

	clock.tick(60)
	
	pygame.display.flip()

pygame.quit()